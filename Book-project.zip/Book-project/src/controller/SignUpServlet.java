package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.User;
import model.UserDaoImpl;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet({ "/SignUpServlet", "/signup" })
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String userId=request.getParameter("userId");
		String password=request.getParameter("password");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String role=request.getParameter("role");
		String email=request.getParameter("email");
		String cpwd=request.getParameter("cpassword");
		if(role.equals("Choose..."))
		{
			out.print("Invalid role. Choose correctly.");
			return;
		}
		String password1=request.getParameter("password");
		if(!password1.equals(cpwd))
		{
			out.print("Password and confirm password does not match. Click <a href=signup.jsp> here </a> to signup.");
			return;
		}
		String status="pending";
		
		MessageDigest md = null;
		
		try {
			md=MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
		// bytes to hex
        StringBuilder sb = new StringBuilder();
        for (byte b : hashInBytes) 
        {
            sb.append(String.format("%02x", b));
        }
        System.out.println(password);
		password=sb.toString();		//this is the encrypted password
		
		User user=new User(userId, password, firstName, lastName, role, status,email);
		UserDaoImpl udao=new UserDaoImpl();
		int no=0;
		try {
			no=udao.create(user);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(no==1)
			out.print("Registration is successful. Click<a href=login.jsp> here </a>to login");
		else
		{
			out.print("Something wrong");
			return;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
