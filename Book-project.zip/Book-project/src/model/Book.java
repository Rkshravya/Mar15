package model;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import org.apache.tomcat.util.codec.binary.Base64;
public class Book 
{

	private Long bookId;
	private String title;
	private String authorName;
	private Date publishedDtae;
	private String country;
	private byte[] picture;
	transient SimpleDateFormat sdf;
	transient SimpleDateFormat sdf2;
	public Book() 
	{
		sdf=new SimpleDateFormat("dd-MMM-yy");
		sdf2=new SimpleDateFormat("yyyy-MM-dd");
	}

	public Book(Long bookId, String title, String authorName, Date publishedDtae, String country, byte[] picture) {
		this();
		this.bookId = bookId;
		this.title = title;
		this.authorName = authorName;
		this.publishedDtae = publishedDtae;
		this.country = country;
		this.picture = picture;
	}

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Date getPublishedDtae() {
		return publishedDtae;
	}

	public String getPublishedDtae1() {
		return sdf.format(publishedDtae);
	}

	public String getPublishedDtae2() {
		return sdf2.format(publishedDtae);
	}
	public void setPublishedDtae(Date publishedDtae) {
		this.publishedDtae = publishedDtae;
	}
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public byte[] getPicture() {
		return picture;
	}

	public String getPicture1()
	{
		String x=Base64.encodeBase64String(picture);
		return x;
	}
	public void setPicture(byte[] picture) {
		this.picture = picture;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", authorName=" + authorName + ", publishedDate="
				+ publishedDtae + ", country=" + country + ", picture=" + picture.length+ "]";
	}
	
}
