package view;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import model.Book;
import model.BookDaoImpl;

/**
 * Servlet implementation class BookController
 */
@MultipartConfig
@WebServlet("/BookController")
public class BookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
String btn=request.getParameter("btn");
		
		Long bookId=Long.valueOf(request.getParameter("bookId"));
		String title="";
		String authorName="";
		String sdate="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date publishedDate=null;
		String country="";
		Book book=null;
		BookDaoImpl adao=new BookDaoImpl();
		int no=0;
		if(btn.equals("Add") || btn.equals("Modify"))
		{
			title=request.getParameter("title");
			authorName=request.getParameter("authorName");
			sdate=request.getParameter("publishedDate");
			
			try {
				publishedDate=sdf.parse(sdate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(publishedDate==null)
				return;
			
			country=request.getParameter("country");
			book=new Book(bookId, title, authorName, publishedDate, country, null);
		}
		switch(btn)
		{
		case "Add":
			if(book!=null)
			{
				try {
					no=adao.create(book);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(no+" row inserted");
			}
			break;
		case "Modify":
			if(book!=null)
			{
				try {
					no=adao.update(book);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(no+" row updated");
			}
			break;
		case "Delete":
			try {
				no=adao.delete(bookId);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(no+" row delete");
			break;
		}
		
		response.sendRedirect("Book.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String btn=request.getParameter("btn");
		
		Long bookId=Long.valueOf(request.getParameter("bookId"));
		String title="";
		String authorName="";
		String sdate="";
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date publishedDate=null;
		String country="";
		Book book=null;
		BookDaoImpl adao=new BookDaoImpl();
		int no=0;
		if(btn.equals("Add") || btn.equals("Modify"))
		{
			title=request.getParameter("title");
			authorName=request.getParameter("authorName");
			sdate=request.getParameter("publishedDate");
			
			try {
				publishedDate=sdf.parse(sdate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(publishedDate==null)
				return;
			
			country=request.getParameter("country");
			//code for accessing file contents as byte array
			Part part = request.getPart("picture");
			InputStream is = part.getInputStream();
			int len = is.available();
			byte []picture=new byte[len];
			is.read(picture);
			
			book=new Book(bookId, title, authorName, publishedDate, country, picture);
			System.out.println("BookController, line 153: "+book);
		}
		switch(btn)
		{
		case "Add":
			if(book!=null)
			{
				try {
					no=adao.create(book);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(no+" row inserted");
			}
			break;
		case "Modify":
			if(book!=null)
			{
				try {
					no=adao.update(book);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(no+" row updated");
			}
			break;
		case "Delete":
			try {
				no=adao.delete(bookId);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(no+" row delete");
			break;
		}
		//redirect back to jsp again
		response.sendRedirect("Book.jsp");

	}

}
